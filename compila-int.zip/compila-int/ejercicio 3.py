Sucursales=["a1","b2","c3","d4","e5","f6","g7","8h","9i","10j","11k","m12","n13","o14","p15","q16","r17","s18","t19","u20","v21","w21","x23","y24","z25"]
Ventas=[210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234]
Superior=[]
promedio= sum(Ventas)/ len(Ventas)
for contador in range(25):
    if Ventas[contador] > promedio:
        Superior.append(Sucursales[contador])

print("El promedio de ventas es ",promedio)
print("las empresas que superan el promedio son:" , Superior)