#ejercicio 1
print("Ingrese 10 numeros")
suma=0
for x in range(10):
    a=int(input())
    suma=suma+a

promedio=suma/10
print("la suma es:",suma)
print("el promedio es: ",promedio)
#ejercicio 2


#ejercicio 3