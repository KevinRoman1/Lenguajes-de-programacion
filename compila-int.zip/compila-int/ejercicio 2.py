import random
pares=0
impares=0
for x in range(500):
    a=random.randint(50,100)
    if a % 2 == 0:
        pares=pares+1
    else:
        impares=impares+1
print("Hay ",pares," numeros pares y ",impares," numeros impares")