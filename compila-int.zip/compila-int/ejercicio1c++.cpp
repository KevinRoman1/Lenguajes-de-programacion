#include <iostream>
using namespace std;

int main() {
    int suma = 0, a;
    
    cout << "Ingrese 10 numeros" << endl;
    
    for (int x = 0; x < 10; x++) {
        cin >> a;
        suma += a;
    }

    float promedio = suma / 10.0;

    cout << "La suma es: " << suma << endl;
    cout << "El promedio es: " << promedio << endl;

    return 0;
}